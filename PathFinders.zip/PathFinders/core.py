import const
import cv2
import time


class Core:
    """The Core class used as an interface between the sensors and the respective classes to perceive and take actions"""

    def __init__(self):
        self.ready = False
        self.detectors = []
        self.cap = cv2.VideoCapture(0)
        self.exit = False
        self.pause = False
        self.vehicle = None

    def registerDetector(self, det):
        """Registers a detector"""
        self.detectors.append(det)


    def checkReadiness(self):
        if self.vehicle is None:
            self.ready = False
        self.ready = True

    def pauseLoop(self, pause, time=5):
        self.pause = True
        self.pauseTime = time

    def resumeLoop(self):
        self.pause = False

    def exitLoop(exit=False):
        self.exit = exit

    def start(self):
        """Starts the main loop. Which receives input from the sensors,
         camera in our case and gives it to the Detector classes for processing.
         Then it gives the result to the vehicle class."""
        if self.ready:
            while not self.exit:
                if self.pause is True:
                    time.sleep(self.pauseTime)
                    self.resumeLoop()

                rval, frame = self.cap.read()

                if not rval:
                    print("Failed to open webcam. Breaking loop.")
                    self.ready = False
                    break

                frame = cv2.flip(frame, 1, 0)
                res = {}

                for det in self.detectors:
                	res[det.__name__] = det.decision(frame, res)
                print(res)
            #    self.vehicle.take_action(res)

        else:
            print("Couldn't start the Main loop. Main loop not ready.")

    def clear_queues(self):
        for x in self.detectors:
            x.queue = []

    def registerVehicle(self, veh):
        self.vehicle = veh

import cv2
import time

size = 2
vs = cv2.VideoCapture(0)
fn_haar ="haarcascade_frontalface_default.xml"
haar_cascade = cv2.CascadeClassifier(fn_haar)
(im_width, im_height) = (112, 92)
color_frame = (0, 255, 0)

hog = cv2.HOGDescriptor()
hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())


class Coord:
    def __init__(self,x,y,w,h):
        self.x=x
        self.y=y
        self.w=w
        self.h=h

frames = []

while True:
    rval = False
    while(not rval):
        (rval, frame) = vs.read()
        if(not rval):
            print("Failed to open webcam. Trying again...")
    frame = cv2.flip(frame, 1, 0)
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    mini = cv2.resize(gray, (int(gray.shape[1] / size), int(gray.shape[0] / size)))
    faces = haar_cascade.detectMultiScale(mini)

    (rects, weights) = hog.detectMultiScale(mini, winStride=(4, 4), padding=(8, 8), scale=1.05)

    print(rects, weights)
    #for i in range(len(faces)):
    if len(faces) > 0:
        face_i = faces[0]
        (x, y, w, h) = [v * size for v in face_i]
        coords = Coord(x,y,w,h)
        frames.append(coords)
        face = gray[y:y + h, x:x + w]
        face_resize = cv2.resize(face, (im_width, im_height))
        cv2.rectangle(frame, (x, y), (x + w, y + h), color_frame, 3)
    result=["none","none","none"]

    if len(frames) is 10:
        first = frames.pop(0)
        last = frames[8]
        
        if first.x - last.x < -15 :
            result[0]="right"
        elif first.x-last.x >15:
            result[0]="left"
        else:
            result[0]="none"
        if first.y-last.y <-15:
            result[1]="down"
        elif first.y-last.y >15:
            result[1]="up"
        else:
            result[1]="none"
        if first.w-last.w <-10:
            result[2]="towards"
        elif first.w-last.w >10:
            result[2]="away"
        else:
            result[2]="none"
    cv2.putText(frame,'%s, %s, %s' % (result[0], result[1], result[2]), (20, 20), cv2.FONT_HERSHEY_PLAIN, 2, (0, 255, 0), 2,)
            
        
            

    cv2.imshow("Hello", frame)
    cv2.waitKey(10)


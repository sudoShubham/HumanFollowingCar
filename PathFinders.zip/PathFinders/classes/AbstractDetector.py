from abc import ABC, abstractmethod


class AbstractDetector(ABC):
    """
    An abstract class to provide uniformity between the different detector classes that perform different functions.
    """

    def __init__(self, core):
        self.core = core
        super().__init__()

    @abstractmethod
    def decision(self, frame, res):
        pass

class DecisionMaker:
    
    def __init__(self, core):
        self.core = core

    def make_decision(self, input):
        dec = []
        return dec

import RPi.GPIO as gpio
import time


class Car:
	"""
	Car class to take decision and then take appropriate action by controlling the motors.
	"""

	def __init__(self, core):
		self.core = core

	def init(self):
		"""To initialize the GPIO input output pins"""
		gpio.setmode(gpio.BOARD)
		gpio.setup(7,gpio.OUT)
		gpio.setup(11,gpio.OUT)
		gpio.setup(13,gpio.OUT)
		gpio.setup(15,gpio.OUT)

	def forward(self, tf):
		"""To move forward"""
		self.init()
		gpio.output(7, False)
		gpio.output(11, True)
		gpio.output(13, True)
		gpio.output(15, False)
		time.sleep(tf)
		gpio.cleanup()

	def reverse(self, tf):
		"""To move backwards"""
		self.init()
		gpio.output(7, True)
		gpio.output(11, False)
		gpio.output(13, False)
		gpio.output(15, True)
		time.sleep(tf)
		gpio.cleanup()

	def turn_right(self, tf):
		"""To turn right"""
		self.init()
		gpio.output(7, True)
		gpio.output(11, True)
		gpio.output(13, True)
		gpio.output(15, False)
		time.sleep(tf)
		gpio.cleanup()

	def turn_left(self, tf):
		"""To turn left"""
		self.init()
		gpio.output(7, False)
		gpio.output(11, True)
		gpio.output(13, False)
		gpio.output(15, False)
		time.sleep(tf)
		gpio.cleanup()

	def take_action(self, res):
		"""To take appropriate decision by the results of the detectors."""
		dir_ = res['DirectionDetector']
		#gest = res['TeachDetector']
		#if gest["Left"] > 0.5:
		#	print("Turn Right")
		#	self.turn_right(0.2)
		#if gest["Right"] > 0.7:
		#	print("Turn Left")
		#	self.turn_left(0.2)
		if dir_[2] == -1:
			print("Should move forward")
			self.forward(1.8)
			self.core.clear_queues()


	def stop(self):
		gpio.cleanup()

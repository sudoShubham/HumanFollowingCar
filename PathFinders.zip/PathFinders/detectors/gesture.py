from classes.AbstractDetector import AbstractDetector
import cv2
import numpy as np
from keras import models
from const import KERAS_MODEL
img_rows, img_cols, img_depth = 35, 35, 15
NO_FRAMES = 15

class GestureDetector(AbstractDetector):

    __name__ = "GestureDetector"

    def __init__(self, core):
        self.core = core
        self.model = models.load_model(KERAS_MODEL)
        self.queue = []
        self.arr = np.empty((1, 1, img_rows, img_cols, img_depth), np.dtype('uint8'))

    def decision(self, frame, res):
        frame=cv2.resize(frame, (img_rows, img_cols), interpolation=cv2.INTER_AREA)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        self.queue.append(gray)
        if len(self.queue) > NO_FRAMES:
            self.queue.pop(0)
            input = np.array(self.queue)
            ipt = np.rollaxis(np.rollaxis(input, 2, 0), 2, 0)
            self.arr[0][0] = np.array(ipt)
            return self.model.predict(self.arr)
        return []

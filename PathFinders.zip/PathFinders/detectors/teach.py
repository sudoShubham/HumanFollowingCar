import cv2
import requests
import json
import base64
import PIL.Image
from classes.AbstractDetector import AbstractDetector

QUEUE_SIZE = 5


class TeachDetector(AbstractDetector):
	"""
	A Detector which sends a request to the API endpoint of our server that hosts the model for gesture detection.
	"""
	__name__ = "TeachDetector"

	def __init__(self, core):
		self.core = core
		self.queue = []

	def im2json(self, im):
		"""Convert a Numpy array to JSON string"""
		return base64.b64encode(im).decode("utf-8")

	def decision(self, frame, res):
		"""
		Send request and provide return the output to core.
		"""
		frame_ = cv2.resize(frame, (200, 200), interpolation=cv2.INTER_AREA)
		img = PIL.Image.fromarray(frame_)
		img.save('./uploads/all.png')
		with open('./uploads/all.png', 'rb') as fil_:
			my_string = base64.b64encode(fil_.read())
		ret = requests.post("http://127.0.0.1:3000/upload", data={ 'image': my_string}).json()['pred']
		return ret

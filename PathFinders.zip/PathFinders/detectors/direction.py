from classes.AbstractDetector import AbstractDetector

from const import QUEUE_LEN, OFFSET_POS_X, OFFSET_NEG_X, OFFSET_POS_Y, OFFSET_NEG_Y, OFFSET_POS_W, OFFSET_NEG_W


class DirectionDetector(AbstractDetector):
    """
    Detect the change in position after comparing it with the previous position.
    """
    __name__ = "DirectionDetector"

    def __init__(self, core):
        self.core = core
        self.queue = []

    def decision(self, frame, res):
        result=[0, 0, 0]
        coord = res["HumanDetector"]
        self.queue.append(coord)
        if len(self.queue) is 10:
            first = self.queue.pop(0)
            last = self.queue[8]

            if first.x - last.x < OFFSET_NEG_X :
                result[0]=1
            elif first.x-last.x >OFFSET_POS_X:
                result[0]=-1
            else:
                result[0]=0
            if first.y-last.y <OFFSET_NEG_Y:
                result[1]=-1
            elif first.y-last.y >OFFSET_POS_Y:
                result[1]=1
            else:
                result[1]=0
            if first.w-last.w < OFFSET_NEG_W:
                result[2]=1
            elif first.w-last.w > OFFSET_POS_W:
                result[2]=-1
            else:
                result[2]=0
        return result

import cv2

from classes.AbstractDetector import AbstractDetector
from helpers.coord import Coord
from const import SIZE, HAAR_PATH



class HumanDetector(AbstractDetector):
    """
    Detects if a human is present in the frame and returns its position.
    """

    __name__ = "HumanDetector"

    def __init__(self, core):
    	self.haar_cascade = cv2.CascadeClassifier(HAAR_PATH)
    	self.core = core
    	self.prev = Coord(0, 0, 10, 10)

    def decision(self, frame, res):
    	result = self.prev
    	gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    	mini = cv2.resize(gray, (int(gray.shape[1] / SIZE), int(gray.shape[0] / SIZE)))
    	faces = self.haar_cascade.detectMultiScale(mini)
        

    	if len(faces) > 0:
    		face_i = faces[0]
    		(x, y, w, h) = [v * SIZE for v in face_i]
    		coords = Coord(x,y,w,h)
    		result = coords
    		self.prev = coords
    	return result

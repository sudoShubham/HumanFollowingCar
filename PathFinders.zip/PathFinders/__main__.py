from core import Core
from detectors.human import HumanDetector
from detectors.direction import DirectionDetector
#from detectors.teach import TeachDetector
#from classes.car import Car

import cv2

if __name__ == "__main__":
    #creating an instance of core, only one instance
    core = Core()

    #initializing detectors. more will be added as time
    human = HumanDetector(core)
    direction = DirectionDetector(core)
#    teach = TeachDetector(core)
    #registering them with the core objects
    core.registerDetector(human)
    core.registerDetector(direction)
    #core.registerDetector(teach)

    #creating and registering the car object which will also take decisions.
#    car = Car(core)
#    core.registerVehicle(car)

    #starting the main loop
    core.checkReadiness()
    if core.ready:
        #try:
        core.start()
        #except:
        #    car.stop()

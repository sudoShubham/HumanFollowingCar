HAAR_PATH = "./models/haarcascade_frontalface_default.xml"
KERAS_MODEL = "./models/model.h5"
SIZE = 2


QUEUE_LEN = 10
OFFSET_POS_X = 15
OFFSET_NEG_X = -15
OFFSET_POS_Y = 10
OFFSET_NEG_Y = -10
OFFSET_POS_W = 2
OFFSET_NEG_W = -2
